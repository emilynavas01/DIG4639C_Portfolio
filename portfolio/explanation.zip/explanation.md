 I selected option 2 of the assignement. 
 https://github.com/UCF-GaiM/dig4639-s23-main-emilynavas01.git
 https://github.com/emilynavas01/DIG4639C_Portfolio.git

 The header componenet displays the header of the application, including the logo and the navigation menu. It doesn't receive any parameters or state, but it contains links to navigate to different pages of the application. 
 The WorkoutList component displays a list of workouts with their corresponding details, such as the name, image, duration, and level. It receives an array of workout objects as a parameter and displays each object as a separate workout item.
 The Profile component displays the user's profile information, such as their name, email, and profile picture. It doesn't receive any parameters or state, but it can be extended to receive user data as a parameter in the future.
 The components meet the requirements of the assignment by effectively displaying information and providing interactivity for the user.